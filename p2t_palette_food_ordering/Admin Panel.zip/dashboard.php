<?php
   /*----- Header -----*/
   include('template/header.php');
   /*----- Header -----*/
?>





<?php
/*----- Footer -----*/
include('template/footer.php');
/*----- Footer -----*/
?>


