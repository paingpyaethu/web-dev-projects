<?php require_once "core/auth.php"; ?>
<?php include "template/header.php"; ?>

   <h1>Dashboard</h1>
   <?php print_r($_SESSION['user']) ?>

<?php include "template/footer.php"; ?>